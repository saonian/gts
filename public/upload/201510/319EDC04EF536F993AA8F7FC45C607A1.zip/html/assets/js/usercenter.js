$(function(){
	var vertical_array=new Array();
	//左侧tab切换
	$(".center-right-box li").eq(0).addClass("active");
	$(".account-security").click(function(){
		$(".center-right-box li").removeClass("active");
		$(this).parent().addClass("active");
		$(".account-safety-box").show().siblings().hide();
	});
	$(".personal-info").click(function(){
		$(".center-right-box li").removeClass("active");
		$(this).parent().addClass("active");
		$(".my-info-box").show().siblings().hide();
	});
	$(".binding-authority").click(function(){
		$(".center-right-box li").removeClass("active");
		$(this).parent().addClass("active");
		$(".binding-authority-box").show().siblings().hide();
	});
	//底部语言切换
	$(".footer p a").click(function(){
		$(".footer p a").removeClass("active");
		$(this).addClass("active");
	});
	
	
	//账号密码弹窗
	$('.progressbar').each(function(index, el) {
		var num = $(this).find('span').text();
		$(this).addClass('progressbar-' + num);
	});
	$(".changepassBtn").click(function(){
		$("#changePassBox").fadeIn(300);
	});
	$(".changePassNext").click(function(){
		$(".change-pass-box").show();
		$(".struggle_changePassBox_form").hide();
	});
	$(".changeverify_btn").on("click",".changePassNext",function(){
		if($(".change-pass-top>p>span")!=""||$(".change-pass-top>p>span")!="undifined"){
			clearInterval(timer);
			var number=10;
			var timer=setInterval(function(){
				if(number>0){
					number=number-1;
					$(".change-pass-top>p>span").html(number);
				}else if(number==0){
					$("#changePassBox").hide();
				}
			},1000);
		}
	});
	$(".relogin").click(function(){
		$("#changePassBox").hide();
	});
	
	
	//安全邮箱/安全手机
	$(".bindingemailBtn").click(function(){
		$("#accountVerification").fadeIn(300);
	});
	$(".account-btn-next1").click(function(){
		$(".account-content-1").hide();
		$(".account-content-2").show();
	});
	$(".changeverify_btn").on("click", ".account-btn-next1",function(){
		if($(".struggle_resent_box>.struggle_resent>span")!=""||$(".struggle_resent_box>.struggle_resent>span")!="undifined"){
			clearInterval(timer);
			var number=60;
			var timer=setInterval(function(){
				if(number>0){
					number=number-1;
					$(".struggle_resent_box>.struggle_resent>span").html("("+number+")");
				}else{
					$(".struggle_resent_box>.struggle_resent>span").empty();
				}
			},1000);
		}
	});
	
	$(".binding-btn-next1").click(function(){
		$("#bindingEmailStep span").removeClass("active");
		$("#bindingEmailStep span:eq(2)").addClass("active");
		$(".binding-content").hide();
		$(".binding-content-2").show();
	});
	$(".binding-btn-next2").click(function(){
		$("#bindingEmailStep span").removeClass("active");
		$("#bindingEmailStep span:last-child").addClass("active");
		$(".binding-content").hide();
		$(".binding-content-3").show();
	});
	$(".binding-btn-close").click(function(){
		$("#bindingEmail").fadeOut(300);
	});
	$(".changeverify_btn").on("click", ".binding-btn-next1",function(){
		if($(".struggle_resent_box>.struggle_resent>span")!=""||$(".struggle_resent_box>.struggle_resent>span")!="undifined"){
			clearInterval(timer);
			var number=60;
			var timer=setInterval(function(){
				if(number>0){
					number=number-1;
					$(".struggle_resent_box>.struggle_resent>span").html("("+number+")");
				}else{
					$(".struggle_resent_box>.struggle_resent>span").empty();
				}
			},1000);
		}
	});
	$(".account-btn-next2").click(function(){
		$("#accountVerification").hide();
		$("#bindingEmail").show();
	});
	
	
	
	$(".safetyphoneBtn").click(function(){
		$("#safetyPhone").fadeIn(300);
	});
	$(".phone-btn-next1").click(function(){
		$("#safetyPhoneStep span").removeClass("active");
		$("#safetyPhoneStep span:eq(2)").addClass("active");
		$(".phone-content").hide();
		$(".phone-content-2").show();
	});
	$(".phone-btn-next2").click(function(){
		$("#safetyPhoneStep span").removeClass("active");
		$("#safetyPhoneStep span:last-child").addClass("active");
		$(".phone-content").hide();
		$(".phone-content-3").show();
	});
	$(".phone-btn-close").click(function(){
		$("#safetyPhone").fadeOut(300);
	});
	$(".changeverify_btn").on("click", ".phone-btn-next1",function(){
		if($(".struggle_resent_box>.struggle_resent>span")!=""||$(".struggle_resent_box>.struggle_resent>span")!="undifined"){
			clearInterval(timer);
			var number=60;
			var timer=setInterval(function(){
				if(number>0){
					number=number-1;
					$(".struggle_resent_box>.struggle_resent>span").html("("+number+")");
				}else{
					$(".struggle_resent_box>.struggle_resent>span").empty();
				}
			},1000);
		}
	});
	
	
	//密保问题
	$(".settingquestionBtn").click(function(){
		$("#securityQuestion").fadeIn(300);
	});
	/*$(".problem_list li a").click(function(){
		//$(this).parent().parent().prev().val($(this).text());
		$(this).parent().parent().prev().attr("value",$(this).text());
	});*/
	/*$(".security-btn-close").click(function(){
//		$("#securityQuestion").fadeOut(300);
	});*/
	
	
	//设置头像弹窗
	$("#settingHead").click(function(){
		$("#avatar-modal").fadeIn(300);
	});
	$('#img-container > img').cropper({
		aspectRatio: 1/1,
		autoCropArea: 0.65,
	});
	$(".share-file-box").hide();
	$(".center-save").parent().hide();
	$(".first-file input").click(function(){
		$(".input-cancel").parent().hide();
		$(".center-save").parent().show();	
		$(".input-btn").removeClass("btn-hightlight").addClass("btn-dark");
	});
	$(".tanc-close-btn").click(function(){
		$(".tanc-box").hide();
	});
	$(".my-avatar-box").hover(
		function(){
			$(".edit-my-avatar").show();
		},
		function(){
			$(".edit-my-avatar").hide();
		}
	);
	$(".edit-my-avatar").click(function(){
		$(".tanc-box").show();
		$(".file-content").show();
	});
	$(".center-right-box li").click(function(){
		$(this).addClass("active").siblings().removeClass("active");
	});
	
	
	//编辑基本资料
	$("#updateData").click(function(){
		$("#basicData").fadeIn(300);
	});
	//个人信息-编辑-性别选择
	$('#sex label').click(function(){
	    var radioId = $(this).attr('name');
	    $('label').removeAttr('class') && $(this).attr('class', 'checked');
	    $('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
	});
	
	
	//绑定授权
	$("#boundQQ").click(function(){
		$("#releaseBoundQQ").fadeIn(300);
	});
	$("#boundWX").click(function(){
		$("#releaseBoundWX").fadeIn(300);
	});
	$("#boundWB").click(function(){
		$("#releaseBoundWB").fadeIn(300);
	});
	$(".close-bound").click(function(){
		$("#releaseBoundQQ,#releaseBoundWX,#releaseBoundWB").fadeOut(300);
	});
	
	
	
	//退出账号
	$(".exit").click(function(){
		$("#exitAccount").fadeIn(300);
	});
	$(".tanc-close-btn,.closeExitAccount").click(function(){
		$("#exitAccount,#basicData,#changepassword,#safeEmail").fadeOut(300);
	});
	
});

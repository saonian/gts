var htmlval = '<div class="padding10"><i class="icon iconfontucenter">&#xe623;</i></div>';
var messages_email_require=htmlval + "邮箱不能为空";
var messages_email_valid=htmlval + "您输入的E-Mail格式不正确";
var messages_email_pass=htmlval + "密码不能为空";
var messages_email_passlength=htmlval + "请输入{0}-{1}密码";
var messages_securityCode=htmlval + "验证码不能为空";
var messages_DouPass=htmlval + "两次密码输入不一致";

//安全手机
var messages_attribution=htmlval + "归属地不能为空";
var messages_phone_require=htmlval + "手机号不能为空";
var messages_phone_length=htmlval + "您输入的手机号格式不正确";

//密保问题
var messages_question_require=htmlval + "问题不能为空";
var messages_answer_require=htmlval + "答案不能为空";

//基础资料
var messages_name_require=htmlval + "姓名不能为空";
var messages_name_length=htmlval + "姓名长度为{0}-{1}位字符";
var messages_birthday_require=htmlval + "请选择出生日期";
















$(function() {
	//账号密码
	var validate = $(".struggle_changePassBox_form").validate({
		debug: true, //调试模式取消submit的默认提交功能
		//errorClass: "label.error", //默认为错误的样式类为：error
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element){
	        $(element).valid();
	    },
		onkeyup: false,
		/*submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
			form.submit(); //提交表单
		},*/
		rules: {
			oldPasswprd:{
				required: true,
				rangelength: [5, 16]
			},
			registerPass: {
				required: true,
				rangelength: [5, 16]
			},
			registerDouPass: {
				equalTo: "#password"
			}
		},
		messages: {
			oldPasswprd: {
				required: messages_email_pass,
				rangelength: $.validator.format(messages_email_passlength)
			},
			registerPass: {
				required: messages_email_pass,
				rangelength: $.validator.format(messages_email_passlength)
			},
			registerDouPass: {
				equalTo: messages_DouPass
			}
		}
	});
	
	//安全邮箱-账号安全验证
	var validate = $(".struggle_uc_verlid_form").validate({
		debug: true, //调试模式取消submit的默认提交功能
		//errorClass: "label.error", //默认为错误的样式类为：error
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element){
	        $(element).valid();
	    },
		onkeyup: false,
		/*submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
			form.submit(); //提交表单
		},*/
		rules: {
			securityCode: {
				required: true,
			}
		},
		messages: {
			securityCode: {
				required: messages_securityCode
			}
		}
	});
	
	//安全邮箱-绑定
	var validate = $(".binding_email_form1").validate({
		debug: true, //调试模式取消submit的默认提交功能
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element) {
			$(element).valid();
		},
		onkeyup: false,
		submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
		 	form.submit(); //提交表单
		},
		rules: {
			Mailbox: {
				required: true,
				email: true
			},
			mailboxCode1: {
				required: true,
			}
		},
		messages: {
			Mailbox: {
				required: messages_email_require,
				email: messages_email_valid
			},
			mailboxCode1: {
				required: messages_securityCode
			}
		}
	});
	var validate = $(".binding_email_form2").validate({
		debug: true, //调试模式取消submit的默认提交功能
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element) {
			$(element).valid();
		},
		onkeyup: false,
		submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
		 	form.submit(); //提交表单
		},
		rules: {
			mailboxCode2: {
				required: true
			}
		},
		messages: {
			mailboxCode2: {
				required: messages_securityCode
			}
		}
	});
	
	//安全手机
	var validate = $(".safety_phone_form1").validate({
		debug: true, //调试模式取消submit的默认提交功能
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element) {
			$(element).valid();
		},
		onkeyup: false,
		submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
		 	form.submit(); //提交表单
		},
		rules: {
			attribution: {
				required: true
			},
			cellNember: {
				required: true,
				rangelength: [11,11]
			},
			cellNemberCode1: {
				required: true
			}
		},
		messages: {
			attribution: {
				required: messages_attribution
			},
			cellNember: {
				required: messages_phone_require,
				rangelength: $.validator.format(messages_phone_length)
			},
			cellNemberCode1: {
				required: messages_securityCode
			}
		}
	});
	var validate = $(".safety_phone_form2").validate({
		debug: true, //调试模式取消submit的默认提交功能
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element) {
			$(element).valid();
		},
		onkeyup: false,
		submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
		 	form.submit(); //提交表单
		},
		rules: {
			cellNemberCode2: {
				required: true
			}
		},
		messages: {
			cellNemberCode2: {
				required: messages_securityCode
			}
		}
	});
	
	//密保问题
	var validate = $(".security_question_form").validate({
		debug: true, //调试模式取消submit的默认提交功能
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element) {
			$(element).valid();
		},
		onkeyup: false,
		/*submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
		 	alert("提交表单");
		 	form.submit(); //提交表单
		},*/
		rules: {
			problemSel1: {
				required: true
			},
			securityAnswer1: {
				required: true
			},
			problemSel2: {
				required: true
			},
			securityAnswer2: {
				required: true
			},
			problemSel3: {
				required: true
			},
			securityAnswer3: {
				required: true
			}
		},
		messages: {
			problemSel1: {
				required: messages_question_require
			},
			securityAnswer1: {
				required: messages_answer_require
			},
			problemSel2: {
				required: messages_question_require
			},
			securityAnswer2: {
				required: messages_answer_require
			},
			problemSel3: {
				required: messages_question_require
			},
			securityAnswer3: {
				required: messages_answer_require
			}
		}
	});
	
	//基本资料修改	
	var validate = $(".basic_data_form").validate({
		debug: true, //调试模式取消submit的默认提交功能
		focusInvalid: false, //当为false时，验证无效时，没有焦点响应
		onfocusout: function(element) {
			$(element).valid();
		},
		onkeyup: false,
		// submitHandler: function(form) { //表单提交句柄,为一回调函数，带一个参数：form
		// 	alert("提交表单");
		// 	form.submit(); //提交表单
		// },
		rules: {
			username: {
				required: true,
				rangelength: [2, 12]
			},
			birthday: {
				required: true,
			}
		},
		messages: {
			username: {
				required: messages_name_require,
				rangelength: $.validator.format(messages_name_length)
			},
			birthday: {
				required: messages_birthday_require
			}
		}
	});
	
	
});
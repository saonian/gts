window.onload=function(){
    var runPage,
        interval,
        autoPlay;

    autoPlay = function(to) {

        clearTimeout(interval);
        interval = setTimeout(function() {
            runPage.go(to);
        }, 3000);

    }
    runPage = new FullPage({
        id : 'pageContain',                           // id of contain
        fullControl:false,
        slideTime : 800,                               // time of slide
        continuous:true,
        effect : {                                     // slide effect
            transform : {
                translate : 'X',                       // 'X'|'Y'|'XY'|'none'
                scale : [1, 1],                    // [scalefrom, scaleto]
                rotate : [0, 0]                    // [rotatefrom, rotateto]
            },
            opacity : [1, 1]                           // [opacityfrom, opacityto]
        },
        mode : 'touch,nav:slideNavBar',               // mode of fullpage
        easing : [0, .93, .39, .98],                               // easing('ease','ease-in','ease-in-out' or use cubic-bezier like [.33, 1.81, 1, 1] )
        callback : function(index, thisPage) {     // callback when pageChange

            index = index + 1 > 3 ? 0 : index + 1;
            autoPlay(index);
        }
    });

    interval = setTimeout(function() {
        runPage.go(runPage.thisPage() + 1);
    }, 3000);
    var prev = document.getElementById('slideLeft'),
    next = document.getElementById('slideRight');

    prev.onclick = function() {
        runPage.go(runPage.thisPage() - 1);
    }
    next.onclick = function() {
        runPage.go(runPage.thisPage() + 1);
    }
};
$(function(){
    var SupportsTouches = ("createTouch" in document),
        StartEvent = SupportsTouches ? "touchstart" : "mousedown"
    var wWidth=$(window).width();
    var contentHeight=parseInt(wWidth*408/(454*4))+"px";
    $(".struggle_content_box a").css({"height":contentHeight});
    // $(".struggle_content_box .struggle_text").css({"lineHeight":contentHeight});
    // $(".struggle_menu").hover(function(){
    //     $(this).children(".struggle_top_menuSlide").slideDown("slow");

    // },function(){
    //     $(this).children(".struggle_top_menuSlide").slideUp("slow");
    // });
    $("#search").focus();
    $(".navbar-right li").hover(function(){
        $(this).addClass("active");
    },function(){
        $(this).removeClass("active");
    });
    $(".navbar-right li a.search_box").hover(function(){
        $(this).children("#search").filter(':not(:animated)').delay(100).animate({"width":"50px"},"slow");
    },function(){
        $(this).children("#search").filter(':not(:animated)').delay(100).animate({"width":"0px"},"slow");
    })
    $(".navbar-right li.active .country_box ul li").hover(function(){
        $(this).addClass("active");
    },function(){
        $(this).removeClass("active");
    })
    $(".country_slide").hover(function(){
        $(".country_box").filter(':not(:animated)').delay(100).slideDown("slow");
    },function(){
        $(".country_box").filter(':not(:animated)').delay(100).slideUp("slow");
    });
     $(".navbar-right li.active .country_box ul li").click(function(){
        $(".country_select").find("img").remove();
        $(this).find("img").clone().appendTo($(".country_select"));
        $(".navbar-right li.active .country_box").css({"display":"none"});
     });
     var aa=$(".struggle_menu").offset().left;
     bb=$(".struggle_menu").offset().right;
     console.log(aa);
     console.log(bb);
});
(function($){
    var SupportsTouches = ("createTouch" in document),
        StartEvent = SupportsTouches ? "touchstart" : "mousedown"
    $.fn.hoverForIE6=function(option){
        var s=$.extend({current:"hover",delay:10},option||{});
        $.each(this,function(){
            var timer1=null,timer2=null,flag=false;
            $(this).bind("mouseover StartEvent",function(){
                if (flag){
                    clearTimeout(timer2);
                }else{
                    var _this=$(this);
                    timer1=setTimeout(function(){
                        _this.children(".struggle_top_menuSlide").filter(':not(:animated)').delay(100).slideDown();
                        flag=true;
                    },s.delay);
                }
            }).bind("mouseout",function(){
                if (flag){
                    var _this=$(this);timer2=setTimeout(function(){
                        _this.children(".struggle_top_menuSlide").filter(':not(:animated)').delay(100).slideUp();
                        flag=false;
                    },s.delay);
                }else{
                    clearTimeout(timer1);
                }
            })
        })
    }
})(jQuery);
$(".struggle_menu").hoverForIE6({delay:200});

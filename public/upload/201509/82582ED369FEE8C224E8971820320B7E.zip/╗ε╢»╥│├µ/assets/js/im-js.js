$(function(){
	footerP();
	$(window).resize(function(){
		footerP();
	})
	//选择机型
	$(".type-box a").click(function(){
		$(".type-box li").removeClass("active");
		$(this).parent("li").addClass("active");
	})
	//筛选类型
	$(".normal-choice a").click(function(){
		$(".normal-choice li").removeClass("active");
		$(this).parent("li").addClass("active");
		var index=$(this).parents(".normal-choice").index();
		var newIndex=index-1;
		$(".download-result>div").hide();
		$(".download-result>div").eq(newIndex).show();
	})
})
function footerP(){
	var wH=$(window).height();
	var bH=$("body").height();
	if(wH<bH){
		$("#im-footer").removeClass("im-fix-footer");
	}else{
		$("#im-footer").addClass("im-fix-footer");
	}
}
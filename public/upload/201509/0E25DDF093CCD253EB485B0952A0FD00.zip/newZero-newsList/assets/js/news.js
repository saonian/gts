$(function(){
	//宽屏时加载
	$.ajax({
        type: "GET",
        //url: "http://127.0.0.1:8080/newZero/testNew.json",
        url: "http://127.0.0.1/project/newZero-newsList/testNew.json",
        dataType: "json",
        success: function(data){
 			//console.log(data[0]["title"]);
 			//data[0]
            $('.divtest').empty();   //清空resText里面的所有内容
            var html = ''; 
            $.each(data, function(contentIndex, content){
            	html += '<a href="javascript:newsDetail1();" class="new_list_article" id="newsDetail1"><div class="title">'+content['title']
                +'</div><div class="detail"><div class="left_img"><img src="'+content['imgUrl']
                +'" width="100%" /></div><div class="right_content"><div class="time">'+content['time']
                +' </div><div class="describle">'+content['description']+' </div></div></div></a>';
                //console.log(html);
            });
            $('.new_list_content').append(html);
        }
    });
    //小屏幕时加载
    $.ajax({
        type: "GET",
        url: "http://127.0.0.1/project/newZero-newsList/testNew.json",
        dataType: "json",
        success: function(data){
            $('.divtest').empty();   //清空resText里面的所有内容
            var html = ''; 
            $.each(data, function(contentIndex, content){
            	html += '<a href="http://127.0.0.1/project/newZero-newsList/newsdetail.html" onclick="newsDetail2();" class="new_list_article" id="newsDetail2"><div class="title">'+content['title']
                +'</div><div class="detail"><div class="left_img"><img src="'+content['imgUrl']
                +'" width="100%" /></div><div class="right_content"><div class="time">'+content['time']
                +' </div><div class="describle">'+content['description']+' </div></div></div></a>';
            });
            $('.new_list_content').append(html);
        }
    });
    //新闻详情页面
    $.ajax({
		type: "get",
        url: "http://127.0.0.1/project/newZero-newsList/newsDetail.json",
		dataType: "json",
		success: function(data){
			console.log(data);
			$('#newRightDetail').empty();
			var html = '';
			$.each(data, function(contentIndex, content){
				html += '<h2>'+content['title']+'</h2>' +
						'<span class="description">作者：'+content['author']+'</span>' +
						'<span class="description">'+content['time']+' 第'+content['times']+'期</span>' +
						'<p class="first_text">'+content['navigation']+'</p>' +
						'<div class="left_box"><img src="'+content['imgUrl']+'" width="100%"><span>'+content['imgTitle']+'</span></div>' +
						'<div class="right_box"><img src="'+content['imgUrl']+'" width="100%"><span>'+content['imgTitle']+'</span></div>' +
		            	'<p>'+content['description']+'</p>';
						console.log(html);
			});
			$('#newRightDetail').append(html);
		}
	});	
    
});

//2015加载更多
function getNewsMore2015(){
	$.ajax({
        type: "GET",
        url: "http://127.0.0.1/project/newZero-newsList/testNew.json",
        dataType: "json",
        success: function(data){
            $('.divtest').empty();   //清空resText里面的所有内容
            var html = ''; 
            $.each(data, function(contentIndex, content){
            	html += '<a href="javascript:newsDetail();" class="new_list_article"><div class="title">'+content['title']
                +'</div><div class="detail"><div class="left_img"><img src="'+content['imgUrl']
                +'" width="100%" /></div><div class="right_content"><div class="time">'+content['time']
                +' </div><div class="describle">'+content['description']+' </div></div></div></a>';
            });
            $('#news2015').append(html);
        }
    });
}
//2014加载更多
function getNewsMore2014(){
	$.ajax({
        type: "GET",
        url: "http://127.0.0.1/project/newZero-newsList/testNew.json",
        dataType: "json",
        success: function(data){
            $('.divtest').empty();   //清空resText里面的所有内容
            var html = ''; 
            $.each(data, function(contentIndex, content){
            	html += '<a href="javascript:newsDetail();" class="new_list_article"><div class="title">'+content['title']
                +'</div><div class="detail"><div class="left_img"><img src="'+content['imgUrl']
                +'" width="100%" /></div><div class="right_content"><div class="time">'+content['time']
                +' </div><div class="describle">'+content['description']+' </div></div></div></a>';
            });
            $('#news2014').append(html);
        }
    });
}
//点击事件-查看详情
function newsDetail1(){
	$.ajax({
		type: "get",
        url: "http://127.0.0.1/project/newZero-newsList/newsDetail.json",
		dataType: "json",
		beforeSend: function(XMLHttpRequest){
			$(".loading").show();
		},
		success: function(data){
			console.log(data);
			$('#newRight').empty();
			var html = '';
			$.each(data, function(contentIndex, content){
				html += '<h2>'+content['title']+'</h2>' +
						'<span class="description">作者：'+content['author']+'</span>' +
						'<span class="description">'+content['time']+' 第'+content['times']+'期</span>' +
						'<p class="first_text">'+content['navigation']+'</p>' +
						'<div class="left_box"><img src="'+content['imgUrl']+'" width="100%"><span>'+content['imgTitle']+'</span></div>' +
						'<div class="right_box"><img src="'+content['imgUrl']+'" width="100%"><span>'+content['imgTitle']+'</span></div>' +
		            	'<p>'+content['description']+'</p>';
						console.log(html);
			});
			$('#newRight').append(html);
		}
	});	
}

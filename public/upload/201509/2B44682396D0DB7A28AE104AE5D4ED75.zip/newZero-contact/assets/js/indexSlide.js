$(function(){
    var SupportsTouches = ("createTouch" in document),
        StartEvent = SupportsTouches ? "touchstart" : "mousedown"
    var wWidth=$(window).width();
    var contentHeight=parseInt(wWidth*408/(454*4))+"px";
    $(".struggle_content_box a").css({"height":contentHeight});
    /*
    $(".struggle_content_box .struggle_text").css({"lineHeight":contentHeight});
    $(".struggle_menu").hover(function(){
        $(this).children(".struggle_top_menuSlide").slideDown("slow");
    },function(){
        $(this).children(".struggle_top_menuSlide").slideUp("slow");
    });
    */
	//$("#search").focus();
    $(".navbar-right li").hover(function(){
        $(this).addClass("active");
    },function(){
        $(this).removeClass("active");
    });
    /*$(".navbar-right li a.search_box").hover(function(){
        $(this).children("#search").filter(':not(:animated)').delay(100).animate({"width":"100px"},"slow");
    },function(){
        $(this).children("#search").filter(':not(:animated)').delay(100).animate({"width":"0px"},"slow");
    })*/
    $(".navbar-right li.active .country_box ul li").hover(function(){
        $(this).addClass("active");
    },function(){
        $(this).removeClass("active");
    })
    $(".country_slide").hover(function(){
        $(".country_box").filter(':not(:animated)').delay(100).slideDown("slow");
    },function(){
        $(".country_box").filter(':not(:animated)').delay(100).slideUp("slow");
    });
     $(".navbar-right li.active .country_box ul li").click(function(){
        $(".country_select").find("img").remove();
        $(this).find("img").clone().appendTo($(".country_select"));
        $(".navbar-right li.active .country_box").css({"display":"none"});
     });
     var aa=$(".struggle_menu").offset().left;
     bb=$(".struggle_menu").offset().right;
     console.log(aa);
     console.log(bb);
});
(function($){
    var SupportsTouches = ("createTouch" in document),
        StartEvent = SupportsTouches ? "touchstart" : "mousedown"
    $.fn.hoverForIE6=function(option){
        var s=$.extend({current:"hover",delay:10},option||{});
        $.each(this,function(){
            var timer1=null,timer2=null,flag=false;
            $(this).bind("mouseover StartEvent",function(){
                if (flag){
                    clearTimeout(timer2);
                }else{
                    var _this=$(this);
                    timer1=setTimeout(function(){
                        _this.children(".struggle_top_menuSlide").filter(':not(:animated)').delay(100).slideDown();
                        flag=true;
                    },s.delay);
                }
            }).bind("mouseout",function(){
                if (flag){
                    var _this=$(this);timer2=setTimeout(function(){
                        _this.children(".struggle_top_menuSlide").filter(':not(:animated)').delay(100).slideUp();
                        flag=false;
                    },s.delay);
                }else{
                    clearTimeout(timer1);
                }
            })
        })
    }
})(jQuery);
$(".struggle_menu").hoverForIE6({delay:200});
